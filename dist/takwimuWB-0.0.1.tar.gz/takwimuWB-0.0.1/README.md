# takwimuWB

This is a simple package that allows for downloading of indicator data specific to Takwimu.

You can use the package to download and structure the data to fit hurumap format
to create visualizations on the go !
